let btn = document.getElementById('btn')
btn.onclick = function () {
  window.location = '/post'
}