## 说明

项目是基于Node开发的后端服务器，实现简单的用户发表评论系统。

## 启动

1. `git clone` 代码克隆到本地

2. `node app.js` node环境运行app.js
