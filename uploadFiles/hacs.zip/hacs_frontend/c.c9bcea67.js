const a=a=>`https://brands.home-assistant.io/${a.useFallback?"_/":""}${a.domain}/${a.darkOptimized?"dark_":""}${a.type}.png`,s=a=>a.split("/")[4];export{a as b,s as e};
